
CREATE TABLE CIT_ESPECIALIDAD (
    esp_codigo numeric(5) default nextval('CIT_ESPECIALIDAD_SEQ') NOT NULL,
    esp_nombre VARCHAR(255) NOT NULL,
    PRIMARY KEY (esp_codigo)
);
commit;
CREATE TABLE CIT_MEDICAS (
    med_codigo numeric(5) default nextval('CIT_MEDICAS_SEQ') NOT NULL,
    med_nombre VARCHAR(100) NOT NULL,
    med_apellido VARCHAR(100) NOT NULL,
    med_cedula VARCHAR(10) NOT NULL,
    med_edad numeric(5) NOT NULL,
    med_especialidad numeric(5) NOT NULL,
    med_direccion VARCHAR(100) NOT NULL,
    med_correo VARCHAR(80) NOT NULL,
    med_password VARCHAR(20) NOT NULL,
    med_telefono VARCHAR(10) NOT NULL,
    PRIMARY KEY (med_codigo)
);
commit;
CREATE TABLE CIT_PACIENTES (
    pac_nombre VARCHAR(100) NOT NULL,
    pac_apellido VARCHAR(100) NOT NULL,
    pac_cedula VARCHAR(10) NOT NULL,
    pac_edad numeric(5) NOT NULL,
    pac_sexo VARCHAR(100) NOT NULL,
    pac_direccion VARCHAR(100) NOT NULL,
    pac_correo VARCHAR(80) NOT NULL,
    pac_password VARCHAR(20) NOT NULL,
    PRIMARY KEY (pac_cedula)
);
commit;
CREATE TABLE CIT_ADMIN (
    adm_codigo numeric(5) default nextval('CIT_ADMIN_SEQ') NOT NULL NOT NULL,
    adm_correo VARCHAR(80) NOT NULL,
    adm_password VARCHAR(20) NOT NULL,
    PRIMARY KEY (adm_codigo)
);
commit;
CREATE TABLE CIT_CITAS(
    ci_codigo numeric (5) default nextval('CIT_CITAS_SEQ') NOT NULL,
    ci_fecha DATE NOT NULL,
    ci_cedula VARCHAR(10) NOT NULL,
    ci_hora numeric(5) NOT NULL,
    ci_minuto numeric(5) NOT NULL,
    ci_segundo numeric(5) NOT NULL,
    ci_aprovacion numeric(5) NOT NULL,
    ci_causa VARCHAR(200) NOT NULL,
    ci_codigoMedico numeric(5) NOT NULL,
    PRIMARY KEY (ci_codigo)
);
ALTER TABLE CIT_CITAS
    ADD CONSTRAINT cit_cit_pac_fk FOREIGN KEY ( ci_cedula )
        REFERENCES CIT_PACIENTES ( pac_cedula );
        
ALTER TABLE CIT_MEDICAS 
    ADD CONSTRAINT cit_med_esp_fk FOREIGN KEY ( med_especialidad )
        REFERENCES CIT_ESPECIALIDAD ( esp_codigo );

ALTER TABLE CIT_CITAS
    ADD CONSTRAINT cit_cit_pac_fk FOREIGN KEY ( ci_cedula )
        REFERENCES CIT_PACIENTES ( pac_cedula );

create sequence CIT_ADMIN_SEQ
start with 2
increment by 1
cycle;
commit;
create sequence CIT_ESPECIALIDAD_SEQ
start with 2
increment by 1
cycle;
commit;
create sequence CIT_CITAS_SEQ
start with 2
increment by 1
cycle;
commit;
create sequence CIT_MEDICAS_SEQ
start with 2
increment by 1
cycle;
commit;

