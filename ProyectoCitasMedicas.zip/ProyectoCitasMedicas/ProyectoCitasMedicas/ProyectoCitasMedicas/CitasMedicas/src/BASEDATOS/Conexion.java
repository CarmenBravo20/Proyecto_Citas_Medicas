/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BASEDATOS;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author campo
 */
public class Conexion {
    
      Connection con=null;
   String user="postgres";
   String pass="carmen123";
   String base="baseCitaMedica";
   String server="localhost";
   String puerto="5432";
   
   String DataBase="jdbc:postgresql://"+server+":"+puerto+"/"+base;
  
   
   
   public Connection conectarBD()throws Exception{
       try{
           Class.forName("org.postgresql.Driver");
           con=DriverManager.getConnection(DataBase,user,pass);
           System.out.println("conexion exitosa");
       }catch(Exception e){
         throw e;
       }
         return con;
   }
   
   
   
   public Connection desconectarBD()throws Exception{
       try{
          if(!con.isClosed() ){
              con.close();
              System.out.println("conexion cerrada"); 
          } 
       }catch(Exception e){
          throw e;
       }
         return con;
   } 
  
}
