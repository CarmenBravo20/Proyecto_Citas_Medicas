/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLADOR;

import BASEDATOS.Conexion;
import MODELO.Factura;
import MODELO.FacturaDetalle;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class ControladorFacDetalle {
    java.sql.Statement st;
    ResultSet rs;
    
    PreparedStatement ps;
    Conexion con=new Conexion();
    
    public void crearFacturaDetalle(FacturaDetalle f){
     Connection conectar;
        try {
            conectar = con.conectarBD();
             st=conectar.createStatement();
         
        String sql = "INSERT INTO CIT_FACTURADETALLE ((fdt_facturacodigo ,fdt_CitaCodigo)) VALUES('"+f.getPrecioConsulta()+"','"+f.getCodigoFactura()+"','"+f.getCodigoCita()+"')";
         System.out.println(sql);
        
        JOptionPane.showMessageDialog(null,"Datos Registrados");
        st.execute(sql);
        st.close();
        con.desconectarBD();
        } catch (Exception ex) {
            Logger.getLogger(ControladorFactura.class.getName()).log(Level.SEVERE, null, ex);
        }
     
     }
}
