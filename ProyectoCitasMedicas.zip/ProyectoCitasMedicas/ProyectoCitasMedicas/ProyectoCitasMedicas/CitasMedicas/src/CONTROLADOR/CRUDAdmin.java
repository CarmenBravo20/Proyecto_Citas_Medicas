/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLADOR;


import BASEDATOS.Conexion;
import MODELO.Administrador;
import MODELO.Especialidad;
import MODELO.Medico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author campo
 */
public class CRUDAdmin {
    DefaultTableModel modeltabla;
    java.sql.Statement st;
    ResultSet rs;
    PreparedStatement ps;
    Medico m=new Medico();
    Especialidad es=new Especialidad();
    Conexion con=new Conexion();
    
    public void registrarMed(Medico m){
    
        try {
            Connection conectar=con.conectarBD();
            st=conectar.createStatement();
            
            String sql="INSERT INTO cit_medicas(med_nombre,med_apellido, med_cedula,med_edad,med_especialidad,med_direccion, med_correo, med_password,med_telefono) VALUES('"+m.getNombre()+"','"+m.getApellido()+"','"+m.getCedula()+"',"
                    + "'"+m.getEdad()+"',"+m.getEspecialidad()+",'"+m.getDireccion()+"','"+m.getCorreo()+"','"+m.getPassword()+"','"+m.getTelefono()+"')";
            
   
        JOptionPane.showMessageDialog(null,"Datos Registrados");
            //System.out.println(sql);
        st.execute(sql);
        st.close();
        con.desconectarBD();  
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,"Datos no guardados");
        }
       
      
    }
   
    public Medico BuscarMed(String cedula){
    try{
      Connection conectar=con.conectarBD();
      st=conectar.createStatement();
      String sql="select * from cit_especialidad a, cit_medicas m where a.esp_codigo=m.med_especialidad and med_cedula='"+cedula+"';";
      
      rs=st.executeQuery(sql);      
      
      if(rs.next()){
        m.setCedula(rs.getString("med_cedula"));  
        m.setNombre(rs.getString("med_nombre"));
        m.setApellido(rs.getString("med_apellido"));
        m.setEdad(rs.getInt("med_edad"));
        m.setCorreo(rs.getString("med_correo"));
        m.setDireccion(rs.getString("med_direccion"));
        //BuscarEspe(m.setEspecialidad(rs.getInt("med_especialidad")));
        m.setEspecialidad(rs.getInt("med_especialidad"));
        m.setPassword(rs.getString("med_password"));   
        m.setTelefono(rs.getString("med_telefono"));  
      }else{  
        
        JOptionPane.showMessageDialog(null, "Datos no encontrados");
      }
        
      st.close();
      con.desconectarBD();
    }catch(Exception ex){
      JOptionPane.showMessageDialog(null, "Error al momento de buscar"+ex);  
    }
    return m;
}
  
    
    

   
    public Administrador Inciarlogin(String user, String pass) {
        
        Administrador a=new Administrador();
        
        String sql="SELECT * FROM CIT_ADMIN   WHERE adm_correo=? AND adm_password=?;";
        
        try {
            Connection conectar=con.conectarBD();
            ps=conectar.prepareStatement(sql);
            ps.setString(1,user);
            ps.setString(2,pass);
            rs= ps.executeQuery();
        while(rs.next()){

            a.setCorreo(rs.getString(1));
            a.setPassword(rs.getString(2));
  
        }
        con.desconectarBD();
       
    } catch (Exception e) {   
    }
    return a; 
    }
    
 ////////////////////////////METODO PARA QUE EL COMBOBOX SE ACTUALIZA CON LAS ESPECIALIDADES QUE SE INGRESA   
    public void llenarcombo(JComboBox cbox) throws Exception{
 
        String sql="SELECT esp_nombre FROM CIT_ESPECIALIDAD  ORDER BY esp_codigo ASC";
         try{          
            Connection conectar=con.conectarBD();
            ps=conectar.prepareStatement(sql);  
            rs= ps.executeQuery();
            
            while(rs.next()){
            cbox.addItem(rs.getString("esp_nombre"));
            
            }
            con.desconectarBD();
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,e);
        }   
    }
/////////////////////////////////////////////////////////////////////////////////////////    

    

/////////////////////////////////CONSULTAS DE ESPECIALIDAD//////////////////////////////////////   
    
    public void RegistrarEsp(Especialidad e) throws Exception{
     try{
    Connection conectar=con.conectarBD();
        st=conectar.createStatement();
         
        String sql = "INSERT INTO CIT_ESPECIALIDAD  (esp_nombre)VALUES('"+e.getEspcialidad()+"')";
        
        JOptionPane.showMessageDialog(null,"Datos Registrados");
        
        st.execute(sql);
        st.close();
        con.desconectarBD();
      }catch(Exception ex){
          throw ex;
      }  
}
      
    
   public void ActualizarEsp(String es)throws Exception{
       try{
        Connection conectar=con.conectarBD();
        st=conectar.createStatement();
        String sql="DELETE FROM CIT_ESPECIALIDAD   WHERE esp_nombre  = '"+es+"');";
        
        st.executeUpdate(sql);
        st.close();
        con.desconectarBD();
        JOptionPane.showMessageDialog(null,"Datos Eliminados");
       
       }catch(Exception e){
           throw e;
       }   
    }  
   
   public void listarEsp(JTable tabla) throws Exception{
            String sql="SELECT * FROM CIT_ESPECIALIDAD  ";    
                 
    Statement st;
    Conexion con = new Conexion();
    Connection conectar=con.conectarBD();
    
    DefaultTableModel model=new DefaultTableModel();
    
         model.addColumn("ID");
         model.addColumn("ESPECIALIDAD");
         tabla.setModel(model);
         
    String[] datos = new String[2];
         try{
             st = conectar.createStatement();
             ResultSet rs=st.executeQuery(sql);
             while(rs.next()){
                 datos[0]=rs.getString(1);
                 datos[1]=rs.getString(2);
                 model.addRow(datos);
             }
   
             con.desconectarBD();
         }catch(SQLException ex){
             JOptionPane.showMessageDialog(null, "Datos no listados"+ex);
         }
   }

 public int ActualizarTabla(String esp,int id) throws Exception{
        int res = 0;
        Connection conectar=con.conectarBD();
        st=conectar.createStatement();
     
        String sql="UPDATE CIT_ESPECIALIDAD  SET esp_nombre='"+esp+"'WHERE esp_codigo="+id+";";
        try{
            ps=conectar.prepareStatement(sql);
            res=ps.executeUpdate();
            if(res>0){
              JOptionPane.showMessageDialog(null,"Dato actualizado de la tabla");  
            }
            System.out.println(sql);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Error al actualizar la tabla");
        }finally{
            ps=null;
            con.desconectarBD();  
        }
        return res;
    }         
 ///////////////////////////////////////////////////////////////////////////////////////////////  
 
 /*
    public void llenarCBXMedicoN(JComboBox cbox) throws Exception{
 
        //String sql="SELECT med_nombre FROM CIT_MEDICAS ORDER BY med_codigo ASC";
        String sql="select * from cit_medicas m, cit_especialidad c where m.med_especialidad = c.esp_codigo";
         try{          
            Connection conectar=con.conectarBD();
            ps=conectar.prepareStatement(sql);  
            rs= ps.executeQuery();
            
            while(rs.next()){
            cbox.addItem(rs.getString("med_nombre"));
            
            }
            con.desconectarBD();
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,e);
        }   
    }
    
     public void llenarCBXEspecialidadN(JComboBox cbox) throws Exception{
 
        //String sql="SELECT med_nombre FROM CIT_MEDICAS ORDER BY med_codigo ASC";
        String sql="select * from cit_especialidad";
         try{          
            Connection conectar=con.conectarBD();
            ps=conectar.prepareStatement(sql);  
            rs= ps.executeQuery();
            
            while(rs.next()){
            cbox.addItem(rs.getString("esp_nombre"));
            
            }
            con.desconectarBD();
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,e);
        }   
    }
     */
    public void llenarhora(JComboBox cbox){
        for (int i = 0; i < 24; ++i) {
            cbox.addItem(i);
    // System.out.println(i);
      }
    }
    
     public void llenarMinutos(JComboBox cbox){
        for (int i = 0; i < 60; ++i) {
            cbox.addItem(i);
     //System.out.println(i);
      }
    }
    public void llenarseg(JComboBox cbox){
        for (int i = 0; i < 60; ++i) {
            cbox.addItem(i);
     //System.out.println(i);
      }
    }
   
        public List<Medico> ListarM() throws Exception{
        try {
            //String sql="SELECT * FROM cit_medicas";
            String sql="select *from cit_medicas";
            Connection conectar=con.conectarBD();
            ps=conectar.prepareStatement(sql);  
            rs= ps.executeQuery();
            List<Medico> lista=new ArrayList<>();
            while(rs.next()){
                 Medico m=new Medico();
                m.setCodigo(rs.getInt(1));
                m.setNombre(rs.getString(2));
                //BuscarEspe(m.setEspecialidad((rs.getInt("esp_codigo"))));
                lista.add(m);
            }
            return lista;
          
        } catch (SQLException ex) {
            
        }
        return null;
            
        }
        
        
        
        public List<Especialidad> ListarE() throws Exception{
        try {
            String sql="SELECT * FROM cit_especialidad ";
            Connection conectar=con.conectarBD();
            ps=conectar.prepareStatement(sql);  
            rs= ps.executeQuery();
            List<Especialidad> lista=new ArrayList<>();
            while(rs.next()){
                 Especialidad e=new Especialidad();
                e.setCodigo(rs.getInt(1));
                e.setEspcialidad(rs.getString(2));
                lista.add(e);
            }
            return lista;
        } catch (SQLException ex) {
            
        }
        return null;
            
    }
      
//----------------------------------------------------------------------------------------Metodo buscar especialidad ---------------------------------------------
         
public Especialidad BuscarEspe(int codigo){
    try{
      Connection conectar=con.conectarBD();
      st=conectar.createStatement();
     
      String sql="select * from cit_medicas m,cit_especialidad a where  m.med_especialidad = a.esp_codigo and ci_codigo = '"+codigo+"';";
      
      rs=st.executeQuery(sql);      
     
      if(rs.next()){
        es.setCodigo(rs.getInt("esp_codigo"));
        es.setEspcialidad(rs.getString("med_especialidad"));
      }else{

        JOptionPane.showMessageDialog(null, "No se encotraron Registros");
      }
       
      st.close();
      con.desconectarBD();
      
    }catch(Exception ex){
      JOptionPane.showMessageDialog(null, "Error al momento de buscar"+ex);  
    } 
   return es;
}

//////////////////////////////////////////////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

}
