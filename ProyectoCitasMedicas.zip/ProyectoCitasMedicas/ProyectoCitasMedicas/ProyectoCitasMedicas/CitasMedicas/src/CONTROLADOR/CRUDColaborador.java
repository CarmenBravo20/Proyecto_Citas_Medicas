/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLADOR;

import BASEDATOS.Conexion;
import MODELO.Colaborador;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author campo
 */
public class CRUDColaborador {
    
    java.sql.Statement st;
    ResultSet rs;
    PreparedStatement ps;
    Conexion con=new Conexion();
    
    
    
    /////////////////////ESTAS SENTENCIA ES PARA LA VENTANA CREAR COLABORADOR ////////////////////////////////    
public void RegistrarCol(Colaborador c) throws Exception{
     try{
    Connection conectar=con.conectarBD();
        st=conectar.createStatement();
         
        String sql = "INSERT INTO colaborador VALUES('"+c.getNombre()+"','"+c.getApellido()+"',"
                                                   +"'"+c.getTelefono()+"','"+c.getCorreo()+"');";
        JOptionPane.showMessageDialog(null,"Datos Registrados");
        st.execute(sql);
        st.close();
        con.desconectarBD();
      }catch(Exception e){
          throw e;
      }  
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void mostrarCol(JTable tabla) throws Exception{
   
     String sql="SELECT * FROM colaborador";    
                 
    Statement st;
    Conexion con = new Conexion();
    Connection Conexion=con.conectarBD();
    
    DefaultTableModel model=new DefaultTableModel();
    
         model.addColumn("NOMBRE");
         model.addColumn("APELLIDO");
         model.addColumn("TELEFONO");
         model.addColumn("CORREO");
        
         tabla.setModel(model);
         
    String[] datos = new String[4];
         try{
             st = Conexion.createStatement();
             ResultSet rs=st.executeQuery(sql);
             while(rs.next()){
                 datos[0]=rs.getString(1);
                 datos[1]=rs.getString(2);
                 datos[2]=rs.getString(3);
                 datos[3]=rs.getString(4);
                
                 model.addRow(datos);
             }
             con.desconectarBD();
         }catch(SQLException e){
             JOptionPane.showMessageDialog(null, "Datos no listados"+e);
         }
  }      
    
    
 public void mostrarMed(JTable tabla, String esp) throws Exception{

     String sql="SELECT m.med_nombre, m.med_apellido, m.med_correo, m.med_especialidad, m.med_telefono \n" +
                   "FROM medico m where m.med_especialidad='"+esp+"';";    
                 
    Statement st;
    Conexion con = new Conexion();
    Connection Conexion=con.conectarBD();
    
    DefaultTableModel model=new DefaultTableModel();
    
         model.addColumn("NOMBRE");
         model.addColumn("APELLIDO");
         model.addColumn("CORREO");
         model.addColumn("ESPECIALIDAD");
         model.addColumn("TELEFONO");
         tabla.setModel(model);
         
    String[] datos = new String[5];
         try{
             st = Conexion.createStatement();
             ResultSet rs=st.executeQuery(sql);
             while(rs.next()){
                 datos[0]=rs.getString(1);
                 datos[1]=rs.getString(2);
                 datos[2]=rs.getString(3);
                 datos[3]=rs.getString(4);
                 datos[4]=rs.getString(5);
                 model.addRow(datos);
             }
             con.desconectarBD();
         }catch(SQLException e){
             JOptionPane.showMessageDialog(null, "Datos no listados"+e);
         }
  }  
 
  ////////////////////////////METODO PARA QUE EL COMBOBOX SE ACTUALIZA CON LAS ESPECIALIDADES QUE SE INGRESA        
  public void llenarcombo(JComboBox cbox) throws Exception{
 
        String sql="SELECT esp_especialidad FROM especialidad ORDER BY esp_id ASC";
         try{          
            Connection conectar=con.conectarBD();
            ps=conectar.prepareStatement(sql);  
            rs= ps.executeQuery();
            
            while(rs.next()){
            cbox.addItem(rs.getString("esp_especialidad"));
            
            }
            con.desconectarBD();
        }catch(SQLException e){
          JOptionPane.showMessageDialog(null,e);
        }   
    }   
    
/////////////////////////////////////////////////////////////////////////////////////////////////////////////    
    
}
