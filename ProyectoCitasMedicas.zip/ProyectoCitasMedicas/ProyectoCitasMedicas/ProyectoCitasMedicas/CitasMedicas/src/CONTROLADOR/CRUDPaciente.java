/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLADOR;

import BASEDATOS.Conexion;
import MODELO.Paciente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author campo
 */
public class CRUDPaciente {
java.sql.Statement st;
ResultSet rs;
Paciente p=new Paciente();
PreparedStatement ps;
Conexion con=new Conexion();

/////////////////////ESTAS SENTENCIAS ES PARA LA VENTANA REGISTRAR PACIENTE ////////////////////////////////    
public void Registrar(Paciente p) throws Exception{
     try{
    Connection conectar=con.conectarBD();
        st=conectar.createStatement();
         
        String sql = "INSERT INTO CIT_PACIENTES (pac_nombre, pac_apellido, pac_cedula, pac_edad, pac_sexo,pac_direccion,pac_correo,pac_password) VALUES('"+p.getNombre()+"','"+p.getApellido()+"','"+p.getCedula()+"',"
                    + "'"+p.getEdad()+"','"+p.getGenero()+"','"+p.getDireccion()+"','"+p.getCorreo()+"','"+p.getPassword()+"')";
         System.out.println(sql);
        
        JOptionPane.showMessageDialog(null,"Datos Registrados");
        st.execute(sql);
        st.close();
        con.desconectarBD();
      }catch(Exception e){
          throw e;
      }  
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////



/////////////////////ESTAS SENTENCIAS ES PARA LA VENTANA LOGIN PACIENTE ////////////////////////////////
public Paciente Inciarlogin(String user, String pass) {
        
        Paciente p=new Paciente();
        
        String sql="SELECT * FROM CIT_PACIENTES  WHERE pac_correo=? AND pac_password=?;";
        
        try {
            Connection conectar=con.conectarBD();
            ps=conectar.prepareStatement(sql);
            ps.setString(1,user);
            ps.setString(2,pass);
            rs= ps.executeQuery();
        while(rs.next()){

            p.setCorreo(rs.getString(7));
            p.setPassword(rs.getString(8));
  
        }
        con.desconectarBD();
       
    } catch (Exception e) {   
    }
    return p; 
    }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////




/////////////////////ESTAS SENTENCIAS ES PARA LA VENTANA ACTUALIZAR PACIENTE ////////////////////////////////
public Paciente Buscar(String cedula){
    try{
      Connection conectar=con.conectarBD();
      st=conectar.createStatement();
      String sql="SELECT *  FROM CIT_PACIENTES  WHERE pac_cedula='"+cedula+"';";
      
      rs=st.executeQuery(sql);      
     
      if(rs.next()){
   
        p.setNombre(rs.getString("pac_nombre"));
        p.setApellido(rs.getString("pac_apellido"));
        p.setCorreo(rs.getString("pac_correo"));
        p.setCedula(rs.getString("pac_cedula"));
        p.setDireccion(rs.getString("pac_direccion"));
        p.setGenero(rs.getString("pac_sexo"));
        p.setPassword(rs.getString("pac_password"));
        p.setEdad(rs.getInt("pac_edad"));
      }else{

        JOptionPane.showMessageDialog(null, "No se encotraron Registros");
      }
       
      st.close();
      con.desconectarBD();
      
    }catch(Exception ex){
      JOptionPane.showMessageDialog(null, "Error al momento de buscar"+ex);  
    } 
   return p;
}


public void Actualizar(Paciente p) {
     Connection conectar;
    try {
        conectar = con.conectarBD();
  
    st=conectar.createStatement();
    String sql="UPDATE CIT_PACIENTES SET pac_nombre='"+p.getNombre()+"',pac_apellido='"+p.getApellido()+"'"
                                                                 + ",pac_correo='"+p.getCorreo()+"'"                                             
                                                                 + ",pac_cedula='"+p.getCedula()+"'"
                                                                 + ",pac_direccion='"+p.getDireccion()+"'"
                                                                 + ",pac_sexo='"+p.getGenero()+"'"
                                                                 + ",pac_password='"+p.getPassword()+"'"
                                                                 + ",pac_edad="+p.getEdad()+" WHERE pac_cedula='"+p.getCedula()+"';";
    
     st.executeUpdate(sql);
     JOptionPane.showMessageDialog(null, "Datos actualizados");
     st.close();
     con.desconectarBD();
       } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "Datos no actualizados"+ex);
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void mostrar(JTable tabla, String ced) throws Exception{
   /*SELECT p.pac_nombre, p.pac_apellido, p.pac_correo,p.pac_cedula,p.pac_direccion,p.pac_sexo,p.pac_edad,c.cit_Ncita,c.cit_medico.c.cit_causa \n" +
                   "from paciente p, cita c where p.pac_cedula=c.pac_cedula;"; */
   
     String sql="SELECT p.pac_nombre, p.pac_apellido, p.pac_correo,p.pac_cedula,p.pac_direccion,p.pac_sexo,p.pac_edad \n" +
                   "from CIT_PACIENTES p where p.pac_cedula='"+ced+"';";    
                 
    Statement st;
    Conexion con = new Conexion();
    Connection Conexion=con.conectarBD();
    
    DefaultTableModel model=new DefaultTableModel();
    
         model.addColumn("NOMBRE");
         model.addColumn("APELLIDO");
         model.addColumn("CORREO");
         model.addColumn("CEDULA");
         model.addColumn("DIRECCION");
         model.addColumn("GENERO");
          model.addColumn("EDAD");
         tabla.setModel(model);
         
    String[] datos = new String[7];
         try{
             st = Conexion.createStatement();
             ResultSet rs=st.executeQuery(sql);
             while(rs.next()){
                 datos[0]=rs.getString(1);
                 datos[1]=rs.getString(2);
                 datos[2]=rs.getString(3);
                 datos[3]=rs.getString(4);
                 datos[4]=rs.getString(5);
                 datos[5]=rs.getString(6);
                 datos[6]=rs.getString(7);
                 model.addRow(datos);
             }
             con.desconectarBD();
         }catch(SQLException e){
             JOptionPane.showMessageDialog(null, "Datos no listados"+e);
         }
    }




}


