/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLADOR;

import BASEDATOS.Conexion;
import MODELO.Factura;
import MODELO.Medico;
import MODELO.Paciente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class ControladorFactura {
    java.sql.Statement st;
    ResultSet rs;
   
    PreparedStatement ps;
    Conexion con=new Conexion();
    
    public void crearFactura(Factura f){
     Connection conectar;
        try {
            conectar = con.conectarBD();
             st=conectar.createStatement();
         
        String sql = "INSERT INTO CIT_FACTURA (fac_fecha ,fac_subtotal ,fac_total ,fac_codMedico ,fac_CodPaciente) VALUES('"+f.getFecha()+"','"+f.getSubtotal()+"','"+f.getTotal()+"',"
                    + "'"+f.getCodigoMedico()+"','"+f.getCodigoPaciente()+"')";
         System.out.println(sql);
        
        JOptionPane.showMessageDialog(null,"Datos Registrados");
        st.execute(sql);
        st.close();
        con.desconectarBD();
        } catch (Exception ex) {
            Logger.getLogger(ControladorFactura.class.getName()).log(Level.SEVERE, null, ex);
        }
     
     }
}
