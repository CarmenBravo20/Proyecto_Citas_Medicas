/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

import java.util.Date;




/**
 *
 * @author ASUS
 */
public class Cita {
    private int codigo;
    private Date fecha;
    private int codPaciente;
    private int hora;
    private  int minuto;
    private int segundo;
    private String causa;
    private int aprovacion;
    private int codigoMedico;

    public Cita() {
    }

    public Cita(int codigo, Date fecha, int codPaciente, int hora, int minuto, int segundo, String causa, int aprovacion, int codigoMedico) {
        this.codigo = codigo;
        this.fecha = fecha;
        this.codPaciente = codPaciente;
        this.hora = hora;
        this.minuto = minuto;
        this.segundo = segundo;
        this.causa = causa;
        this.aprovacion = aprovacion;
        this.codigoMedico = codigoMedico;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getCodPaciente() {
        return codPaciente;
    }

    public void setCodPaciente(int codPaciente) {
        this.codPaciente = codPaciente;
    }

    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {
        this.hora = hora;
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }

    public int getSegundo() {
        return segundo;
    }

    public void setSegundo(int segundo) {
        this.segundo = segundo;
    }

    public String getCausa() {
        return causa;
    }

    public void setCausa(String causa) {
        this.causa = causa;
    }

    public int getAprovacion() {
        return aprovacion;
    }

    public void setAprovacion(int aprovacion) {
        this.aprovacion = aprovacion;
    }

    public int getCodigoMedico() {
        return codigoMedico;
    }

    public void setCodigoMedico(int codigoMedico) {
        this.codigoMedico = codigoMedico;
    }

    
}
