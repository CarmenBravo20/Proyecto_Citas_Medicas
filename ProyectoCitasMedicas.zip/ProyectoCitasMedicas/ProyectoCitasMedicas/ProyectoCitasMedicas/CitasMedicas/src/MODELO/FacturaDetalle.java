/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

/**
 *
 * @author ASUS
 */
public class FacturaDetalle {
    private int codigo;
    private double precioConsulta;
    private int codigoFactura;
    private int codigoCita;

    public FacturaDetalle() {
    }

    public FacturaDetalle(int codigo, double precioConsulta, int codigoFactura, int codigoProducto) {
        this.codigo = codigo;
        this.precioConsulta = precioConsulta;
        this.codigoFactura = codigoFactura;
        this.codigoCita = codigoCita;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public double getPrecioConsulta() {
        return precioConsulta;
    }

    public void setPrecioConsulta(double precioConsulta) {
        this.precioConsulta = precioConsulta;
    }

    public int getCodigoFactura() {
        return codigoFactura;
    }

    public void setCodigoFactura(int codigoFactura) {
        this.codigoFactura = codigoFactura;
    }

    public int getCodigoCita() {
        return codigoCita;
    }

    public void setCodigoCita(int codigoCita) {
        this.codigoCita = codigoCita;
    }

   
}
