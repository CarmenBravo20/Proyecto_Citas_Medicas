/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

import java.util.Date;

/**
 *
 * @author ASUS
 */
public class Factura {
    private int codigo;
    private Date fecha;
    private double subtotal;
    private double total;
    private int codigoPaciente;
    private int codigoMedico;

    public Factura() {
    }

    public Factura(int codigo, Date fecha, double subtotal, double total, int codigoPaciente, int codigoMedico) {
        this.codigo = codigo;
        this.fecha = fecha;
        this.subtotal = subtotal;
        this.total = total;
        this.codigoPaciente = codigoPaciente;
        this.codigoMedico = codigoMedico;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public int getCodigoPaciente() {
        return codigoPaciente;
    }

    public void setCodigoPaciente(int codigoPaciente) {
        this.codigoPaciente = codigoPaciente;
    }

    public int getCodigoMedico() {
        return codigoMedico;
    }

    public void setCodigoMedico(int codigoMedico) {
        this.codigoMedico = codigoMedico;
    }
    
}
