
CREATE TABLE CIT_ESPECIALIDAD (
    esp_codigo numeric(5) default nextval('CIT_ESPECIALIDAD_SEQ') NOT NULL,
    esp_nombre VARCHAR(255) NOT NULL,
    PRIMARY KEY (esp_codigo)
);
commit;
CREATE TABLE CIT_MEDICAS (
    med_codigo numeric(5) default nextval('CIT_MEDICAS_SEQ') NOT NULL,
    med_nombre VARCHAR(100) NOT NULL,
    med_apellido VARCHAR(100) NOT NULL,
    med_cedula VARCHAR(10) NOT NULL,
    med_edad numeric(5) NOT NULL,
    med_especialidad numeric(5) NOT NULL,
    med_direccion VARCHAR(100) NOT NULL,
    med_correo VARCHAR(80) NOT NULL,
    med_password VARCHAR(20) NOT NULL,
    med_telefono VARCHAR(10) NOT NULL,
    PRIMARY KEY (med_codigo)
);
commit;
CREATE TABLE CIT_PACIENTES (
	pac_codigo numeric (5) default nextval('CIT_PACIENTES_SEQ') NOT NULL,
    pac_nombre VARCHAR(100) NOT NULL,
    pac_apellido VARCHAR(100) NOT NULL,
    pac_cedula VARCHAR(10) NOT NULL,
    pac_edad numeric(5) NOT NULL,
    pac_sexo VARCHAR(100) NOT NULL,
    pac_direccion VARCHAR(100) NOT NULL,
    pac_correo VARCHAR(80) NOT NULL,
    pac_password VARCHAR(20) NOT NULL,
    PRIMARY KEY (pac_codigo)
);
COMMIT;
commit;
CREATE TABLE CIT_ADMIN (
    adm_codigo numeric(5) default nextval('CIT_ADMIN_SEQ') NOT NULL NOT NULL,
    adm_correo VARCHAR(80) NOT NULL,
    adm_password VARCHAR(20) NOT NULL,
    PRIMARY KEY (adm_codigo)
);
commit;
CREATE TABLE CIT_CITAS(
    ci_codigo numeric (5) default nextval('CIT_CITAS_SEQ') NOT NULL,
    ci_fecha DATE NOT NULL,
    ci_cedula VARCHAR(10) NOT NULL,
    ci_hora numeric(5) NOT NULL,
    ci_minuto numeric(5) NOT NULL,
    ci_segundo numeric(5) NOT NULL,
    ci_aprovacion numeric(5) NOT NULL,
    ci_causa VARCHAR(200) NOT NULL,
    ci_codigoMedico numeric(5) NOT NULL,
    PRIMARY KEY (ci_codigo)
);
ALTER TABLE CIT_CITAS
    ADD CONSTRAINT cit_cit_pac_fk FOREIGN KEY ( ci_codpaciente )
        REFERENCES CIT_PACIENTES ( pac_codigo );

ALTER TABLE CIT_CITAS
    ADD CONSTRAINT cit_med_pac_fk FOREIGN KEY ( ci_codigoMedico )
        REFERENCES CIT_MEDICAS ( med_codigo );
        
ALTER TABLE CIT_MEDICAS 
    ADD CONSTRAINT cit_med_esp_fk FOREIGN KEY ( med_especialidad )
        REFERENCES CIT_ESPECIALIDAD ( esp_codigo );



create sequence CIT_ADMIN_SEQ
start with 2
increment by 1
cycle;
commit;
create sequence CIT_ESPECIALIDAD_SEQ
start with 2
increment by 1
cycle;
commit;
create sequence CIT_CITAS_SEQ
start with 2
increment by 1
cycle;
commit;
create sequence CIT_MEDICAS_SEQ
start with 2
increment by 1
cycle;
commit;

create sequence CIT_PACIENTES_SEQ
start with 2
increment by 1
cycle;
commit;
create sequence CIT_fACTURA_SEQ
start with 2
increment by 1
cycle;
commit;
create sequence CIT_fACTURADETALLE_SEQ
start with 2
increment by 1
cycle;
commit;

INSERT INTO CIT_PACIENTES (adm_correo,adm_password) VALUES ('admin','admin');
INSERT INTO CIT_ESPECIALIDAD(esp_nombre) VALUES ('Oncologo');
INSERT INTO CIT_MEDICAS (med_nombre,med_apellido,med_cedula,med_edad,med_especialidad,med_direccion,med_correo,med_password,med_telefono) VALUES ('Roberto','Ortega','0106137680',28,2,'Cuenca','roberortega@gmail.com','roberto','0992145612');
INSERT INTO CIT_CITAS (ci_fecha ,ci_codpaciente,ci_hora,ci_minuto,ci_segundo,ci_aprovacion,ci_causa,ci_codigoMedico) VALUES('10/01/2021',2,12,30,00,1,'Sufre de cancer',1);
INSERT INTO CIT_PACIENTES (pac_nombre,pac_apellido,pac_cedula,pac_edad,pac_sexo,pac_direccion,pac_correo,pac_password) VALUES ('Rolando','Calle','0106137680',40,'Masculino','Cuenca','rolando1@gmail.com','rolando');
commit;

CREATE TABLE CIT_FACTURA (
    fac_codigo  NUMBER(5) default nextval('CIT_fACTURA_SEQ') NOT NULL,
    fac_fecha   DATE NOT NULL,
    fac_subtotal   NUMBER(10, 2) NOT NULL,
    fac_total      NUMBER(10, 2) NOT NULL,
    fac_codMedico  NUMBER(5) NOT NULL,
    fac_CodPaciente   NUMBER(5) NOT NULL
    PRIMARY KEY (fac_codigo)
);
commit;
CREATE TABLE CIT_FACTURADETALLE (
    fdt_codigo  NUMBER(5) default nextval('CIT_fACTURADETALLE_SEQ') NOT NULL,
    fdt_PrecioConsulta   NUMBER(10, 2) NOT NULL,
    fdt_facturacodigo   NUMBER(5),
    fdt_CitaCodigo   NUMBER(5) NOT NULL
    PRIMARY KEY (fdt_codigo)
);
commit;
