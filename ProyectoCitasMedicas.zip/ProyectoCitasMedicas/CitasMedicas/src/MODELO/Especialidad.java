/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

/**
 *
 * @author campo
 */
public class Especialidad {
    private int codigo;
    private String espcialidad;

    public Especialidad(String espcialidad, int codigo) {
        this.espcialidad = espcialidad;
        this.codigo = codigo;
    }

    public Especialidad() {
    }

    public String getEspcialidad() {
        return espcialidad;
    }

    public void setEspcialidad(String espcialidad) {
        this.espcialidad = espcialidad;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    
            
    
}
