/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

import java.util.Date;




/**
 *
 * @author ASUS
 */
public class Cita {
    private int codigo;
    private Date fecha;
    private String cedula;
    private int hora;
    private  int minuto;
    private int segundo;
    private String causa;
    private int aprovacion;
    private int codigoMedico;

    public Cita() {
    }

    public Cita(int codigo, Date fecha, String cedula, int hora, int minuto, int segundo, String causa, int aprovacion,int codigoMedico) {
        this.codigo = codigo;
        this.fecha = fecha;
        this.cedula = cedula;
        this.hora = hora;
        this.minuto = minuto;
        this.segundo = segundo;
        this.causa = causa;
        this.aprovacion = aprovacion;
        this.codigoMedico = codigoMedico;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {
        this.hora = hora;
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }

    public int getSegundo() {
        return segundo;
    }

    public void setSegundo(int segundo) {
        this.segundo = segundo;
    }

    public String getCausa() {
        return causa;
    }

    public void setCausa(String causa) {
        this.causa = causa;
    }

    public int getAprovacion() {
        return aprovacion;
    }

    public void setAprovacion(int Aprovacion) {
        this.aprovacion = Aprovacion;
    }

    public int getCodigoMedico() {
        return codigoMedico;
    }

    public void setCodigoMedico(int codigoMedico) {
        this.codigoMedico = codigoMedico;
    }

    @Override
    public String toString() {
        return "Cita{" + "codigo=" + codigo + ", fecha=" + fecha + ", cedula=" + cedula + ", hora=" + hora + ", minuto=" + minuto + ", segundo=" + segundo + ", causa=" + causa + ", aprovacion=" + aprovacion + ", codigoMedico=" + codigoMedico + '}';
    }

   
   
    
}
