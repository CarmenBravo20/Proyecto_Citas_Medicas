/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLADOR;

import BASEDATOS.Conexion;
import MODELO.Cita;
import MODELO.Especialidad;
import MODELO.Medico;
import MODELO.Paciente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ASUS
 */
public class CRUDCitas {
    java.sql.Statement st;
    ResultSet rs;
    Cita c=new Cita();
    Especialidad e=new Especialidad();
    Medico m=new Medico();
    Paciente p=new Paciente();
    PreparedStatement ps;
    Conexion con=new Conexion();
//---------------------------------------------------------MetodCrear CorrectoComprovado-------------------------------------------
public void crear(Cita c) throws Exception{
     try{
    Connection conectar=con.conectarBD();
        st=conectar.createStatement();
         
        String sql = "INSERT INTO CIT_CITAS(ci_fecha ,ci_cedula,ci_hora,ci_minuto,ci_segundo,ci_aprovacion,ci_causa,ci_codigoMedico) VALUES('"+c.getFecha()+"',"
                                                +"'"+c.getCedula()+"','"+c.getHora()+"',"
                                                +"'"+c.getMinuto()+"','"+c.getSegundo()+"',"
                                                +"'"+c.getAprovacion()+"','"+c.getCausa()+"',"
                                                + "'"+c.getCodigoMedico()+"');"; 
        JOptionPane.showMessageDialog(null,"Datos Registrados");
        st.execute(sql);
        st.close();
        con.desconectarBD();
      }catch(Exception e){
          throw e;
      }  
}
//-------------------------------------------------------/////////---------------------------------------------------------

 public List<Cita> buscarCita(int codigo){
     try{
         List<Cita> lista=new ArrayList<>();
      Connection conectar=con.conectarBD();
      st=conectar.createStatement();
      //String sql="SELECT *  FROM CIT_CITAS WHERE ci_codigo='"+codigo+"';";
      String sql="SELECT * FROM CIT_CITAS c, CIT_PACIENTES p, CIT_MEDICAS m, CIT_ESPECIALIDAD a  "
              + "WHERE p.pac_cedula=c.ci_cedula and c.ci_codigoMedico = m.med_codigo and a.esp_codigo = m.med_codigo and ci_codigo = '"+codigo+"';";
      rs=st.executeQuery(sql); 
      
        while(rs.next()){
            c.setFecha(rs.getDate("ci_fecha"));
            c.setCedula(rs.getString("ci_cedula"));
            c.setHora(rs.getInt("ci_hora"));
            c.setMinuto(rs.getInt("ci_minuto"));
            c.setSegundo(rs.getInt("ci_segundo"));
            c.setAprovacion(rs.getInt("ci_aprovacion"));
            c.setCausa(rs.getString("ci_causa"));
            c.setCodigoMedico(rs.getInt("ci_codigoMedico"));
            lista.add(c);
        }
      return lista;
      }catch(Exception ex){
      JOptionPane.showMessageDialog(null, "Error al momento de buscar"+ex);  
    } 
     return  null;
 }
//--------------------------------------------------------------En Funcion--------------------------------------------------
public Cita Buscar(int codigo){
    try{
      Connection conectar=con.conectarBD();
      st=conectar.createStatement();
      //String sql="SELECT *  FROM CIT_CITAS WHERE ci_codigo='"+codigo+"';";
      String sql="SELECT * FROM CIT_CITAS c, CIT_PACIENTES p, CIT_MEDICAS m, CIT_ESPECIALIDAD a  "
              + "WHERE p.pac_cedula=c.ci_cedula and c.ci_codigoMedico = m.med_codigo and a.esp_codigo = m.med_codigo and ci_codigo = '"+codigo+"';";
      
      rs=st.executeQuery(sql);      
     
      if(rs.next()){
        p.setCedula(rs.getString("pac_cedula"));
        p.setNombre(rs.getString("pac_nombre"));
        p.setApellido(rs.getString("pac_apellido"));
        p.setEdad(rs.getInt("pac_edad"));
        p.setGenero(rs.getString("pac_sexo"));
       //e.setEspcialidad(rs.getString("esp_nombre"));
       //m.setNombre(rs.getString("med_nombre"));
        c.setFecha(rs.getDate("ci_fecha"));
        c.setCedula(rs.getString("ci_cedula"));
        c.setHora(rs.getInt("ci_hora"));
        c.setMinuto(rs.getInt("ci_minuto"));
        c.setSegundo(rs.getInt("ci_segundo"));
        c.setAprovacion(rs.getInt("ci_aprovacion"));
        c.setCausa(rs.getString("ci_causa"));
        c.setCodigoMedico(rs.getInt("ci_codigoMedico"));
        //Buscar("pac_cedula");
        //ListarM();
        //ListarP();
      }else{

        JOptionPane.showMessageDialog(null, "No se encotraron Registros");
      }
       
      st.close();
      con.desconectarBD();
      
    }catch(Exception ex){
      JOptionPane.showMessageDialog(null, "Error al momento de buscar"+ex);  
    } 
   return c;
}

//------------------------------------------------------------------------------------------------------------------------------

     public List<Medico> ListarM() throws Exception{
        try {
           // String sql="select cm.med_nombre,es.esp_nombre from cit_citas ci, cit_especialidad es,cit_medicas cm where ci.ci_codigomedico = cm.med_codigo and  cm.med_especialidad = es.esp_codigo";
            String sql="select * from cit_citas ci, cit_especialidad es,cit_medicas cm where ci.ci_codigomedico = cm.med_codigo and  cm.med_especialidad = es.esp_codigo";
           
            Connection conectar=con.conectarBD();
            ps=conectar.prepareStatement(sql);  
            rs= ps.executeQuery();
            List<Medico> lista=new ArrayList<>();
            while(rs.next()){
                 Medico m=new Medico();
                m.setCodigo(rs.getInt(1));
                m.setNombre(rs.getString(2));
                lista.add(m);
            }
            return lista;
        } catch (SQLException ex) {
            
        }
        return null;
            
        }
      public List<Paciente> ListarP() throws Exception{
        try {
            String sql="SELECT * FROM cit_pacientes";
            Connection conectar=con.conectarBD();
            ps=conectar.prepareStatement(sql);  
            rs= ps.executeQuery();
            List<Paciente> lista=new ArrayList<>();
            while(rs.next()){
                 Paciente p=new Paciente();
               // p.setCedula(rs.getString(1));
                p.setNombre(rs.getString(1));
                p.setApellido(rs.getString(2));
                p.setEdad(rs.getInt(3));
                p.setGenero(rs.getString(4));
                lista.add(p);
            }
            return lista;
        } catch (SQLException ex) {
            
        }
        return null;
            
        }
      
      
      
      
//----------------------------------------------------------------------------------------------------------------------------------
    //--------------------//trabajando consulta///--------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------------------
      public List<Cita> buscarCit(int codigo){
     
         
          Connection conectar;
        try {
            conectar = con.conectarBD();
            st=conectar.createStatement();
            
            
             List<Cita> lista=new ArrayList<>();
            String sql="SELECT ci_codigo,ci_fecha ,ci_cedula,ci_hora,ci_minuto,ci_segundo,ci_aprovacion,ci_causa,ci_codigoMedico FROM CIT_CITAS c, CIT_PACIENTES p, CIT_MEDICAS m, CIT_ESPECIALIDAD a  "
              + "WHERE p.pac_cedula=c.ci_cedula and c.ci_codigoMedico = m.med_codigo and a.esp_codigo = m.med_codigo and ci_codigo = '"+codigo+"';";
            
           ps=conectar.prepareStatement(sql);  
            rs= ps.executeQuery();
            
            while(rs.next()){
                Cita c=new Cita();
                c.setCodigo(rs.getInt(1));
                c.setFecha(rs.getDate(2));
                c.setCedula(rs.getString(3));
                c.setHora(rs.getInt(4));
                c.setMinuto(rs.getInt(5));
                c.setSegundo(rs.getInt(6));
                c.setAprovacion(rs.getInt(7));
                c.setCausa(rs.getString(8));
                c.setCodigoMedico(rs.getInt(9));
                System.out.println(c);
                lista.add(c);
               
                
            }
            
            return lista;
            
        } catch (Exception ex) {
            Logger.getLogger(CRUDCitas.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
     }
    public Medico BuscarMed(String cedula){
    try{
      Connection conectar=con.conectarBD();
      st=conectar.createStatement();
      String sql="SELECT *  FROM medico  WHERE med_cedula='"+cedula+"';";
      
      rs=st.executeQuery(sql);      
      
      if(rs.next()){
        m.setCedula(rs.getString("med_cedula"));  
        m.setNombre(rs.getString("med_nombre"));
        m.setEspecialidad(rs.getInt("med_especialidad")); 
          System.out.println(m);
      }else{  
        
        JOptionPane.showMessageDialog(null, "Datos no encontrados");
      }
        
      st.close();
      con.desconectarBD();
    }catch(Exception ex){
      JOptionPane.showMessageDialog(null, "Error al momento de buscar"+ex);  
    }
    return m;
}
}