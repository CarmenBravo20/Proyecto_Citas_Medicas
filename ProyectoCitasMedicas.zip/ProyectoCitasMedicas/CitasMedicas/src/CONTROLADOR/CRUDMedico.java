/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLADOR;


import BASEDATOS.Conexion;
import MODELO.Medico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author campo
 */

public class CRUDMedico {
    java.sql.Statement st;
    ResultSet rs;
    PreparedStatement ps;
    Conexion con=new Conexion();
  
  
    
        public Medico Inciarlogin(String user, String pass) {
        
        Medico m=new Medico();
        
        String sql="SELECT * FROM CIT_MEDICAS  WHERE med_correo=? AND med_password=?;";
        
        try {
            Connection conectar=con.conectarBD();
            ps=conectar.prepareStatement(sql);
            ps.setString(1,user);
            ps.setString(2,pass);
            rs= ps.executeQuery();
        while(rs.next()){

            m.setCorreo(rs.getString(3));
            m.setPassword(rs.getString(8));
  
        }
        con.desconectarBD();
       
    } catch (Exception e) {   
    }
    return m; 
    }
        
  
        
    public void Actualizar(Medico m,String ced) {
     Connection conectar;
    try {
        conectar = con.conectarBD();
  
    st=conectar.createStatement();
    String sql="UPDATE medico SET med_nombre='"+m.getNombre()+"',med_apellido='"+m.getApellido()+"'"
                                                                 + ",med_correo='"+m.getCorreo()+"'"                                             
                                                                 + ",med_cedula='"+m.getCedula()+"'"
                                                                 + ",med_edad="+m.getEdad()+""
                                                                 + ",med_direccion='"+m.getDireccion()+"'"
                                                                 + ",med_especialidad='"+m.getEspecialidad()+"'"
                                                                 + ",med_password='"+m.getPassword()+"'"
                                                                 + ",med_telefono='"+m.getTelefono()+"' WHERE med_cedula='"+ced+"';";
    
        System.out.println(sql);
     st.executeUpdate(sql);
     JOptionPane.showMessageDialog(null, "Datos actualizados");
     st.close();
     con.desconectarBD();
       } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "Datos no actualizados"+ex);
    }
}
    
    
    public void Eliminar(String cedula){
        try {
            Connection conectar=con.conectarBD();
            st=conectar.createStatement();
            
            String sql ="DELETE FROM medico WHERE  med_cedula='"+cedula+"';";
                    
                    
            st.executeUpdate(sql);
            st.close();
            con.desconectarBD();
            JOptionPane.showMessageDialog(null,"Datos del medico Eliminados");        
            } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,"Datos NO Eliminados");
        }
    }
    
    
     public void listarMedi(JTable tabla) throws Exception{
            String sql="SELECT * FROM medico ";    
                 
    Statement st;
    Conexion con = new Conexion();
    Connection conectar=con.conectarBD();
    
    DefaultTableModel model=new DefaultTableModel();
    
         model.addColumn("NOMBRE");
         model.addColumn("APELLIDO");
         model.addColumn("CORREO");
         model.addColumn("CEDULA");
         model.addColumn("EDAD");
         model.addColumn("DIRECCION");
         model.addColumn("ESPECIALIDAD");
         model.addColumn("CONTRASEÑA");
         model.addColumn("TELEFONO");
        
         tabla.setModel(model);
         
    String[] datos = new String[9];
         try{
             st = conectar.createStatement();
             ResultSet rs=st.executeQuery(sql);
             while(rs.next()){
                 datos[0]=rs.getString(1);
                 datos[1]=rs.getString(2);
                 datos[2]=rs.getString(3);
                 datos[3]=rs.getString(4);
                 datos[4]=rs.getString(5);
                 datos[5]=rs.getString(6);
                 datos[6]=rs.getString(7);
                 datos[7]=rs.getString(8);
                 datos[8]=rs.getString(9);
                 
                 model.addRow(datos);
             }
   
             con.desconectarBD();
         }catch(SQLException ex){
             JOptionPane.showMessageDialog(null, "Datos no listados"+ex);
         }
   }
     
  public void mostrarMedPAC(JTable tabla, String ced) throws Exception{
      
//Realizar la consulta


//     String sql="SELECT m.med_nombre, m.med_apellido, m.med_especialidad,p.pac_nombre"
//                               + "p.pac_apellido,p.pac_cedula,p.pac_edad,p.pac_genero,c.cit_fecha,c.cit_hora,c.cit_causa,c.cit_estado\n" +
//                               "FROM medico m ,paciente p, cita c where p.pac_cedula='"+ced+"';";    


    String sql="";
                 
    Statement st;
    Conexion con = new Conexion();
    Connection Conexion=con.conectarBD();
    
    DefaultTableModel model=new DefaultTableModel();
    
         model.addColumn("NOMBRE");
         model.addColumn("APELLIDO");
         model.addColumn("CEDULA");
         model.addColumn("EDAD");
         model.addColumn("GENERO");
         model.addColumn("FECHA");
         model.addColumn("HORA");
         model.addColumn("NOMBRE DOCTOR");
         model.addColumn("APELLIDO DOCTOR");
         model.addColumn("ESPECIALIDAD");
         model.addColumn("CAUSA");
         model.addColumn("ESTADO");
         
         tabla.setModel(model);
         
    String[] datos = new String[12];
         try{
             st = Conexion.createStatement();
             ResultSet rs=st.executeQuery(sql);
             while(rs.next()){
                 datos[0]=rs.getString(1);
                 datos[1]=rs.getString(2);
                 datos[2]=rs.getString(3);
                 datos[3]=rs.getString(4);
                 datos[4]=rs.getString(5);
                 datos[5]=rs.getString(6);
                 datos[6]=rs.getString(7);
                 datos[7]=rs.getString(8);
                 datos[8]=rs.getString(9);
                 datos[9]=rs.getString(10);
                 datos[10]=rs.getString(11);
                 datos[11]=rs.getString(12);
                 model.addRow(datos);
             }
             System.err.println(sql);
             con.desconectarBD();
         }catch(SQLException e){
             JOptionPane.showMessageDialog(null, "Datos no listados"+e);
         }
  }  
  
  
  /*public void Registrar(Medico m, int n) throws Exception{
     try{
    
        PreparedStatement pst=null;
        
        String sql="INSERT INTO CIT_MEDICAS (med_codigo, med_nombre, med_apellido, med_cedula, med_edad, med_especialidad, med_direccion, med_correo, med_password , med_telefono)"
                    + " VALUES (CIT_MEDICAS_SEQ.nextval,?,?,?,?,?,?,?,?,?)";
            
        
            Connection conectar=con.conectarBD();
            st=conectar.createStatement();
            //pst.setInt(1, 6);
            pst.setString(1, m.getNombre());
            pst.setString(2, m.getApellido());
            pst.setString(4, m.getCedula());
            pst.setInt(7, m.getEdad());
            pst.setInt(7, n);
            pst.setString(3, m.getDireccion());
            pst.setString(5, m.getCorreo());
            pst.setString(6, m.getPassword());
            pst.setString(8, m.getTelefono());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Medico Creado Correctamente");
        st.execute(sql);
        st.close();
        con.desconectarBD();
      }catch(Exception e){
          throw e;
      }  
}*/
}
