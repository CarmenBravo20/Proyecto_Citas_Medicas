/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alexa
 */
public class ColaboradorTest {
    
    public ColaboradorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of getNombre method, of class Colaborador.
     */
    @Test
    public void testGetNombre() {
        System.out.println("getNombre");
        Colaborador instance = new Colaborador();
        String nombre="Maria";
        instance.setNombre(nombre);
        String expResult = "Maria";
        String result = instance.getNombre();
        assertEquals(expResult, result);
           assertEquals(expResult, result);
        if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }


    /**
     * Test of setNombre method, of class Colaborador.
     */
    @Test
    public void testSetNombre() {
        System.out.println("setNombre");
        String nombre = "";
        Colaborador instance = new Colaborador();
        instance.setNombre(nombre);
        assertTrue(nombre, true);
    }

    /**
     * Test of getApellido method, of class Colaborador.
     */
    @Test
    public void testGetApellido() {
        System.out.println("getApellido");
        Colaborador instance = new Colaborador();
        String apellido="Barreto";
        instance.setApellido(apellido);
        String expResult = "Barreto";
        String result = instance.getApellido();
        assertEquals(expResult, result);
           assertEquals(expResult, result);
        if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }


    /**
     * Test of setApellido method, of class Colaborador.
     */
    @Test
    public void testSetApellido() {
        System.out.println("setApellido");
        String apellido = "";
        Colaborador instance = new Colaborador();
        instance.setApellido(apellido);
        assertTrue(apellido, true);
    }

    /**
     * Test of getTelefono method, of class Colaborador.
     */
    @Test
    public void testGetTelefono() {
        System.out.println("getTelefono");
        Colaborador instance = new Colaborador();
        String telefono="0968892425";
        instance.setTelefono(telefono);
        String expResult = "0968892425";
        String result = instance.getTelefono();
        assertEquals(expResult, result);
           assertEquals(expResult, result);
        if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    

    }

    /**
     * Test of setTelefono method, of class Colaborador.
     */
    @Test
    public void testSetTelefono() {
        System.out.println("setTelefono");
        String telefono = "";
        Colaborador instance = new Colaborador();
        instance.setTelefono(telefono);
        assertTrue(telefono, true);
    }

    /**
     * Test of getCorreo method, of class Colaborador.
     */
    @Test
    public void testGetCorreo() {
        System.out.println("getCorreo");
        Colaborador instance = new Colaborador();
        String correo="maria123@gmail.com";
        instance.setCorreo(correo);
        String expResult = "maria123@gmail.com";
        String result = instance.getCorreo();
        assertEquals(expResult, result);
       if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setCorreo method, of class Colaborador.
     */
    @Test
    public void testSetCorreo() {
        System.out.println("setCorreo");
        String correo = "";
        Colaborador instance = new Colaborador();
        instance.setCorreo(correo);
        assertTrue(correo, true);
    }
    
}
