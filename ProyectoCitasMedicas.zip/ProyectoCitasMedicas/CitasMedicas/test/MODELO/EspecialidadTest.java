/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alexa
 */
public class EspecialidadTest {
    
    public EspecialidadTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of getEspcialidad method, of class Especialidad.
     */
    @Test
    public void testGetEspcialidad() {
        System.out.println("getEspcialidad");
        Especialidad instance = new Especialidad();
        String especialidad="odontologia";
        instance.setEspcialidad(especialidad);
        String expResult = "odontologia";
        String result = instance.getEspcialidad();
        assertEquals(expResult, result);
        if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }
    /**
     * Test of setEspcialidad method, of class Especialidad.
     */
    @Test
    public void testSetEspcialidad() {
        System.out.println("setEspcialidad");
        String espcialidad = "";
        Especialidad instance = new Especialidad();
        instance.setEspcialidad(espcialidad);
        assertTrue(true);
    }

    /**
     * Test of getCodigo method, of class Especialidad.
     */
    @Test
    public void testGetCodigo() {
        System.out.println("getCodigo");
        Especialidad instance = new Especialidad();
        int codigo=1;
        instance.setCodigo(codigo);
        int expResult = 1;
        int result = instance.getCodigo();
        assertEquals(expResult, result);
         if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setCodigo method, of class Especialidad.
     */
    @Test
    public void testSetCodigo() {
        System.out.println("setCodigo");
        int codigo = 0;
        Especialidad instance = new Especialidad();
        instance.setCodigo(codigo);
        assertTrue(true);
    }
    
}
