/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

import com.sun.corba.se.impl.util.PackagePrefixChecker;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alexa
 */
public class AdministradorTest {
    
    public AdministradorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of getCorreo method, of class Administrador.
     */
    @Test
    public void testGetCorreo() {
        System.out.println("getCorreo");
        Administrador instance = new Administrador();
        String correo="alexandra2@gmail.com";
        instance.setCorreo(correo);
        String expResult = "alexandra2@gmail.com";
        String result = instance.getCorreo();
        assertEquals(expResult, result);
        if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }
    

    /**
     * Test of setCorreo method, of class Administrador.
     */
    @Test
    public void testSetCorreo() {
        System.out.println("setCorreo");
        String correo = "";
        Administrador instance = new Administrador();
        instance.setCorreo(correo);
        assertTrue(correo, true);
        }

    /**
     * Test of getPassword method, of class Administrador.
     */
    @Test
    public void testGetPassword() {
        System.out.println("getPassword");
        Administrador instance = new Administrador();
        String password="1234";
        instance.setPassword(password);
        String expResult = "1234";
        String result = instance.getPassword();
        assertEquals(expResult, result);
     if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }
    

    /**
     * Test of setPassword method, of class Administrador.
     */
    @Test
    public void testSetPassword() {
        System.out.println("setPassword");
        String password = "";
        Administrador instance = new Administrador();
        instance.setPassword(password);
        assertTrue(password, true);
         }
    
}
