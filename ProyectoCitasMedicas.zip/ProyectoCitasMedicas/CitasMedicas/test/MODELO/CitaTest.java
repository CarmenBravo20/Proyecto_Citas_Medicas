/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

import java.util.Date;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alexa
 */
public class CitaTest {
    
    public CitaTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of getCodigo method, of class Cita.
     */
    @Test
    public void testGetCodigo() {
        System.out.println("getCodigo");
        Cita instance = new Cita();
        int codigo=1;
        instance.setCodigo(codigo);
        int expResult = 1;
        int result = instance.getCodigo();
         if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }
        

    /**
     * Test of setCodigo method, of class Cita.
     */
    @Test
    public void testSetCodigo() {
        System.out.println("setCodigo");
        int codigo = 0;
        Cita instance = new Cita();
        instance.setCodigo(codigo);
        assertTrue(true);
    }

    /**
     * Test of getFecha method, of class Cita.
     */
    @Test
    public void testGetFecha() {
        System.out.println("getFecha");
        Cita instance = new Cita();
        //instance.setFecha();
        Date expResult = null;
        Date result = instance.getFecha();
        assertEquals(expResult, result);
         if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setFecha method, of class Cita.
     */
    @Test
    public void testSetFecha() {
        System.out.println("setFecha");
        Date fecha = null;
        Cita instance = new Cita();
        instance.setFecha(fecha);
        assertTrue(true);
    }

    /**
     * Test of getCedula method, of class Cita.
     */
    @Test
    public void testGetCedula() {
        System.out.println("getCedula");
        Cita instance = new Cita();
        String cedula="0107593873";
        instance.setCedula(cedula);
        String expResult = "0107593873";
        String result = instance.getCedula();
        assertEquals(expResult, result);
        if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setCedula method, of class Cita.
     */
    @Test
   public void testSetCedula() {
        System.out.println("setCedula");
        String cedula = "";
        Cita instance = new Cita();
        instance.setCedula(cedula);
        assertTrue(cedula, true);
    }

    /**
     * Test of getHora method, of class Cita.
     */
    
    public void testGetHora() {
        System.out.println("getHora");
        Cita instance = new Cita();
        int hora=1;
        instance.setHora(hora);
        int expResult = 1;
        int result = instance.getHora();
        assertEquals(expResult, result);
     if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setHora method, of class Cita.
     */
    @Test
    public void testSetHora() {
        System.out.println("setHora");
        int hora = 0;
        Cita instance = new Cita();
        instance.setHora(hora);
        assertTrue(true);
    }

    /**
     * Test of getMinuto method, of class Cita.
     */
    @Test
    public void testGetMinuto() {
        System.out.println("getMinuto");
        Cita instance = new Cita();
        int minuto=1;
        instance.setMinuto(minuto);
        int expResult = 1;
        int result = instance.getMinuto();
        assertEquals(expResult, result);
      if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setMinuto method, of class Cita.
     */
    @Test
    public void testSetMinuto() {
        System.out.println("setMinuto");
        int minuto = 0;
        Cita instance = new Cita();
        assertTrue(true);
    }

    /**
     * Test of getSegundo method, of class Cita.
     */
    @Test
    public void testGetSegundo() {
        System.out.println("getSegundo");
        Cita instance = new Cita();
        int segundo=0;
        instance.setSegundo(segundo);
        int expResult = 0;
        int result = instance.getSegundo();
        assertEquals(expResult, result);
        if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setSegundo method, of class Cita.
     */
    @Test
    public void testSetSegundo() {
        System.out.println("setSegundo");
        int segundo = 0;
        Cita instance = new Cita();
        instance.setSegundo(segundo);
        assertTrue(true);
    }

    /**
     * Test of getCausa method, of class Cita.
     */
    @Test
    public void testGetCausa() {
        System.out.println("getCausa");
        Cita instance = new Cita();
        String causa="Sufre cáncer";
        instance.setCausa(causa);
        String expResult = "Sufre cáncer";
        String result = instance.getCausa();
        assertEquals(expResult, result);
        if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setCausa method, of class Cita.
     */
    @Test
    public void testSetCausa() {
        System.out.println("setCausa");
        String causa = "";
        Cita instance = new Cita();
        instance.setCausa(causa);
        assertTrue(causa, true);
    }

    /**
     * Test of getAprovacion method, of class Cita.
     */
    @Test
    public void testGetAprovacion() {
        System.out.println("getAprovacion");
        Cita instance = new Cita();
        int aprobacion=1;
        instance.setAprovacion(aprobacion);
        int expResult = 1;
        int result = instance.getAprovacion();
        assertEquals(expResult, result);
       if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setAprovacion method, of class Cita.
     */
    @Test
    public void testSetAprovacion() {
        System.out.println("setAprovacion");
        int Aprovacion = 0;
        Cita instance = new Cita();
        instance.setAprovacion(Aprovacion);
        assertTrue(true);
    }

    /**
     * Test of getCodigoMedico method, of class Cita.
     */
    @Test
    public void testGetCodigoMedico() {
        System.out.println("getCodigoMedico");
        Cita instance = new Cita();
        int codigom=1;
        instance.setCodigoMedico(codigom);
        int expResult = 1;
        int result = instance.getCodigoMedico();
        assertEquals(expResult, result);
       if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setCodigoMedico method, of class Cita.
     */
    @Test
    public void testSetCodigoMedico() {
        System.out.println("setCodigoMedico");
        int codigoMedico = 0;
        Cita instance = new Cita();
        instance.setCodigoMedico(codigoMedico);
        assertTrue(true);
    }

    /**
     * Test of toString method, of class Cita.
     */
  
    
}
