/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alexa
 */
public class PacienteTest {
    
    public PacienteTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of getNombre method, of class Paciente.
     */
    @Test
    public void testGetNombre() {
        System.out.println("getNombre");
        Paciente instance = new Paciente();
        instance.nombre="Luis";
        String expResult = "Luis";
        String result = instance.getNombre();
        assertEquals(expResult, result);
        
       if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }
    

    /**
     * Test of setNombre method, of class Paciente.
     */
    @Test
    public void testSetNombre() {
        System.out.println("setNombre");
        String nombre = "";
        Paciente instance = new Paciente();
        instance.setNombre(nombre);
        assertTrue(nombre, true);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of getApellido method, of class Paciente.
     */
    @Test
    public void testGetApellido() {
        System.out.println("getApellido");
        Paciente instance = new Paciente();
        instance.apellido="Bravo";
        String expResult = "Bravo";
        String result = instance.getApellido();
        assertEquals(expResult, result);
 if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }
    

    /**
     * Test of setApellido method, of class Paciente.
     */
    @Test
    public void testSetApellido() {
        System.out.println("setApellido");
        String apellido = "";
        Paciente instance = new Paciente();
        instance.setApellido(apellido);
        // TODO review the generated test code and remove the default call to fail.
        assertTrue(apellido, true);
//  fail("The test case is a prototype.");
    }

    /**
     * Test of getCedula method, of class Paciente.
     */
    @Test
    public void testGetCedula() {
        System.out.println("getCedula");
        Paciente instance = new Paciente();
        instance.cedula="0107593873";
        String expResult = "0107593873";
        String result = instance.getCedula();
        assertEquals(expResult, result);
         if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }
    

    /**
     * Test of setCedula method, of class Paciente.
     */
    @Test
    public void testSetCedula() {
        System.out.println("setCedula");
        String cedula = "";
        Paciente instance = new Paciente();
        instance.setCedula(cedula);
        assertTrue(cedula, true);
     }

    /**
     * Test of getEdad method, of class Paciente.
     */
    @Test
    public void testGetEdad() {
        System.out.println("getEdad");
        Paciente instance = new Paciente();
        instance.edad=21;
        int expResult = 21;
        int result = instance.getEdad();
        assertEquals(expResult, result);
       if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }
    

    /**
     * Test of setEdad method, of class Paciente.
     */
    @Test
    public void testSetEdad() {
        System.out.println("setEdad");
        int edad = 0;
        Paciente instance = new Paciente();
        instance.setEdad(edad);
        assertTrue(true);
    }

    /**
     * Test of getGenero method, of class Paciente.
     */
    @Test
    public void testGetGenero() {
        System.out.println("getGenero");
        Paciente instance = new Paciente();
        instance.genero="femenino";
        String expResult = "femenino";
        String result = instance.getGenero();
        assertEquals(expResult, result);
       if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }
    

    /**
     * Test of setGenero method, of class Paciente.
     */
    @Test
    public void testSetGenero() {
        System.out.println("setGenero");
        String genero = "";
        Paciente instance = new Paciente();
        instance.setGenero(genero);
        assertTrue(genero, true);
    }

    /**
     * Test of getDireccion method, of class Paciente.
     */
    @Test
    public void testGetDireccion() {
        System.out.println("getDireccion");
        Paciente instance = new Paciente();
        instance.direccion="Cuenca";
        String expResult = "Cuenca";
        String result = instance.getDireccion();
        assertEquals(expResult, result);
       if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }
    

    /**
     * Test of setDireccion method, of class Paciente.
     */
    @Test
    public void testSetDireccion() {
        System.out.println("setDireccion");
        String direccion = "";
        Paciente instance = new Paciente();
        instance.setDireccion(direccion);
        assertTrue(direccion, true);
    }

    /**
     * Test of getCorreo method, of class Paciente.
     */
    @Test
    public void testGetCorreo() {
        System.out.println("getCorreo");
        Paciente instance = new Paciente();
        String correo="alexandra56@gmail.com";
        instance.setCorreo(correo);
        String expResult = "alexandra56@gmail.com";
        String result = instance.getCorreo();
        assertEquals(expResult, result);
 if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }
    

    /**
     * Test of setCorreo method, of class Paciente.
     */
    @Test
    public void testSetCorreo() {
        System.out.println("setCorreo");
        String correo = "";
        Paciente instance = new Paciente();
        instance.setCorreo(correo);
        assertTrue(correo, true);
                }

    /**
     * Test of getPassword method, of class Paciente.
     */
    @Test
    public void testGetPassword() {
        System.out.println("getPassword");
        Paciente instance = new Paciente();
        instance.password="1234";
        String expResult = "1234";
        String result = instance.getPassword();
        assertEquals(expResult, result);
        if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }
    

    /**
     * Test of setPassword method, of class Paciente.
     */
    @Test
    public void testSetPassword() {
        System.out.println("setPassword");
        String password = "";
        Paciente instance = new Paciente();
        instance.setPassword(password);
        assertTrue(password, true);
    }
}
