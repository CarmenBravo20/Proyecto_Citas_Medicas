/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alexa
 */
public class MedicoTest {
    
    public MedicoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of getNombre method, of class Medico.
     */
    @Test
    public void testGetNombre() {
        System.out.println("getNombre");
        Medico instance = new Medico();
        String nombre="Carlos";
        instance.setNombre(nombre);
        String expResult = "Carlos";
        String result = instance.getNombre();
          assertEquals(expResult, result);
        if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setNombre method, of class Medico.
     */
    @Test
    public void testSetNombre() {
        System.out.println("setNombre");
        String nombre = "";
        Medico instance = new Medico();
        instance.setNombre(nombre);
        assertTrue(nombre, true);
    }

    /**
     * Test of getApellido method, of class Medico.
     */
    @Test
    public void testGetApellido() {
        System.out.println("getApellido");
        Medico instance = new Medico();
        String apellido="Arias";
        instance.setApellido(apellido);
        String expResult = "Arias";
        String result = instance.getApellido();
        assertEquals(expResult, result);
        if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setApellido method, of class Medico.
     */
    @Test
    public void testSetApellido() {
        System.out.println("setApellido");
        String apellido = "";
        Medico instance = new Medico();
        instance.setApellido(apellido);
        assertTrue(apellido, true);
    }

    /**
     * Test of getCedula method, of class Medico.
     */
    @Test
    public void testGetCedula() {
        System.out.println("getCedula");
        Medico instance = new Medico();
        String cedula="0107596832";
        instance.setCedula(cedula);
        String expResult = "0107596832";
        String result = instance.getCedula();
        assertEquals(expResult, result);
         if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setCedula method, of class Medico.
     */
    @Test
    public void testSetCedula() {
        System.out.println("setCedula");
        String cedula = "";
        Medico instance = new Medico();
        instance.setCedula(cedula);
        assertTrue(cedula, true);
    }

    /**
     * Test of getEdad method, of class Medico.
     */
    @Test
    public void testGetEdad() {
        System.out.println("getEdad");
        Medico instance = new Medico();
        int edad=21;
        instance.setEdad(edad);
        int expResult = 21;
        int result = instance.getEdad();
       assertEquals(expResult, result);
        if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setEdad method, of class Medico.
     */
    @Test
    public void testSetEdad() {
        System.out.println("setEdad");
        int edad = 0;
        Medico instance = new Medico();
        instance.setEdad(edad);
        assertTrue(true);
    }

    /**
     * Test of getEspecialidad method, of class Medico.
     */
    @Test
    public void testGetEspecialidad() {
        System.out.println("getEspecialidad");
        Medico instance = new Medico();
        String especialidad="odontologia";
        instance.setEspecialidad(0);
        String expResult = "odontologia";
        //String result = instance.getEspecialidad();
        assertTrue(expResult, true);
    }

    /**
     * Test of setEspecialidad method, of class Medico.
     */
    @Test
    public void testSetEspecialidad() {
        System.out.println("setEspecialidad");
        String especialidad = "";
        Medico instance = new Medico();
        assertTrue(especialidad, true);
    }

    /**
     * Test of getDireccion method, of class Medico.
     */
    @Test
    public void testGetDireccion() {
        System.out.println("getDireccion");
        Medico instance = new Medico();
        String direccion="Cuenca";
        instance.setDireccion(direccion);
        String expResult = "Cuenca";
        String result = instance.getDireccion();
        assertEquals(expResult, result);
         if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setDireccion method, of class Medico.
     */
    @Test
    public void testSetDireccion() {
        System.out.println("setDireccion");
        String direccion = "";
        Medico instance = new Medico();
        instance.setDireccion(direccion);
        assertTrue(true);
    }

    /**
     * Test of getCorreo method, of class Medico.
     */
    @Test
    public void testGetCorreo() {
        System.out.println("getCorreo");
        Medico instance = new Medico();
        String correo="luis1@gmail.com";
        instance.setCorreo(correo);
        String expResult = "luis1@gmail.com";
        String result = instance.getCorreo();
        assertEquals(expResult, result);
          if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setCorreo method, of class Medico.
     */
    @Test
    public void testSetCorreo() {
        System.out.println("setCorreo");
        String correo = "";
        Medico instance = new Medico();
        instance.setCorreo(correo);
        assertTrue(correo, true);
    }

    /**
     * Test of getPassword method, of class Medico.
     */
    @Test
    public void testGetPassword() {
        System.out.println("getPassword");
        Medico instance = new Medico();
        String password="1234";
        instance.setPassword(password);
        String expResult = "1234";
        String result = instance.getPassword();
        assertEquals(expResult, result);
          if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setPassword method, of class Medico.
     */
    @Test
    public void testSetPassword() {
        System.out.println("setPassword");
        String password = "";
        Medico instance = new Medico();
        instance.setPassword(password);
        assertTrue(password, true);
    }

    /**
     * Test of getTelefono method, of class Medico.
     */
    @Test
    public void testGetTelefono() {
        System.out.println("getTelefono");
        Medico instance = new Medico();
        String telefono="09689653568";
        instance.setTelefono(telefono);
        String expResult = "09689653568";
        String result = instance.getTelefono();
        assertEquals(expResult, result);
       if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setTelefono method, of class Medico.
     */
    @Test
    public void testSetTelefono() {
        System.out.println("setTelefono");
        String telefono = "";
        Medico instance = new Medico();
        instance.setTelefono(telefono);
        assertTrue(telefono, true);
    }

    /**
     * Test of getCodigo method, of class Medico.
     */
    @Test
    public void testGetCodigo() {
        System.out.println("getCodigo");
        Medico instance = new Medico();
        int codigo=1;
        instance.setCodigo(codigo);
        int expResult = 1;
        int result = instance.getCodigo();
        assertEquals(expResult, result);
         if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of setCodigo method, of class Medico.
     */
    @Test
    public void testSetCodigo() {
        System.out.println("setCodigo");
        int codigo = 0;
        Medico instance = new Medico();
        instance.setCodigo(codigo);
        assertTrue(true);
    }

   
    
}
