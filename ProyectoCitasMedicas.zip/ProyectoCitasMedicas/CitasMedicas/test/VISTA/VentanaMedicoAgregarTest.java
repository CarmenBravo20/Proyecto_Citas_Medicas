/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VISTA;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alexa
 */
public class VentanaMedicoAgregarTest {
    
    public VentanaMedicoAgregarTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of llenarMedico method, of class VentanaMedicoAgregar.
     */
    @Test
    public void testLlenarMedico() {
        System.out.println("llenarMedico");
        VentanaMedicoAgregar instance = new VentanaMedicoAgregar();
        instance.llenarMedico();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of llenarEspecialidad method, of class VentanaMedicoAgregar.
     */
    @Test
    public void testLlenarEspecialidad() {
        System.out.println("llenarEspecialidad");
        VentanaMedicoAgregar instance = new VentanaMedicoAgregar();
        instance.llenarEspecialidad();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
