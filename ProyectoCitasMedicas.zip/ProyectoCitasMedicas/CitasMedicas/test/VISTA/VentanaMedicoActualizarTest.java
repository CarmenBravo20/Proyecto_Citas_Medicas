/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VISTA;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alexa
 */
public class VentanaMedicoActualizarTest {
    
    public VentanaMedicoActualizarTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of buscarCita method, of class VentanaMedicoActualizar.
     */
    @Test
    public void testBuscarCita() {
        System.out.println("buscarCita");
        int codigo = 0;
        VentanaMedicoActualizar instance = new VentanaMedicoActualizar();
        String expResult = "";
        String result = instance.buscarCita(codigo);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of buscarMedico method, of class VentanaMedicoActualizar.
     */
    @Test
    public void testBuscarMedico() {
        System.out.println("buscarMedico");
        int codigo = 0;
        VentanaMedicoActualizar instance = new VentanaMedicoActualizar();
        String expResult = "";
        String result = instance.buscarMedico(codigo);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of actualizarCita method, of class VentanaMedicoActualizar.
     */
    @Test
    public void testActualizarCita() {
        System.out.println("actualizarCita");
        VentanaMedicoActualizar instance = new VentanaMedicoActualizar();
        instance.actualizarCita();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of buscarEspecialidad method, of class VentanaMedicoActualizar.
     */
    @Test
    public void testBuscarEspecialidad() {
        System.out.println("buscarEspecialidad");
        int codigo = 0;
        VentanaMedicoActualizar instance = new VentanaMedicoActualizar();
        String expResult = "";
        String result = instance.buscarEspecialidad(codigo);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of buscarPaciente method, of class VentanaMedicoActualizar.
     */
    @Test
    public void testBuscarPaciente() {
        System.out.println("buscarPaciente");
        String cedula = "";
        VentanaMedicoActualizar instance = new VentanaMedicoActualizar();
        String expResult = "";
        String result = instance.buscarPaciente(cedula);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
