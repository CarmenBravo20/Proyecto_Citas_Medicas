/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLADOR;

import MODELO.Medico;
import javax.swing.JTable;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alexa
 */
public class CRUDMedicoIT {
    
    public CRUDMedicoIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of Inciarlogin method, of class CRUDMedico.
     */
    @Test
    public void testInciarlogin() {
        System.out.println("Inciarlogin");
        String user = "";
        String pass = "";
        CRUDMedico instance = new CRUDMedico();
        Medico expResult = null;
        Medico result = instance.Inciarlogin(user, pass);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Actualizar method, of class CRUDMedico.
     */
    @Test
    public void testActualizar() {
        System.out.println("Actualizar");
        Medico m = null;
        String ced = "";
        CRUDMedico instance = new CRUDMedico();
        instance.Actualizar(m, ced);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Eliminar method, of class CRUDMedico.
     */
    @Test
    public void testEliminar() {
        System.out.println("Eliminar");
        String cedula = "";
        CRUDMedico instance = new CRUDMedico();
        instance.Eliminar(cedula);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of listarMedi method, of class CRUDMedico.
     */
    @Test
    public void testListarMedi() throws Exception {
        System.out.println("listarMedi");
        JTable tabla = null;
        CRUDMedico instance = new CRUDMedico();
        instance.listarMedi(tabla);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of mostrarMedPAC method, of class CRUDMedico.
     */
    @Test
    public void testMostrarMedPAC() throws Exception {
        System.out.println("mostrarMedPAC");
        JTable tabla = null;
        String ced = "";
        CRUDMedico instance = new CRUDMedico();
        instance.mostrarMedPAC(tabla, ced);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
