/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLADOR;

import MODELO.Colaborador;
import javax.swing.JComboBox;
import javax.swing.JTable;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alexa
 */
public class CRUDColaboradorIT {
    
    public CRUDColaboradorIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of RegistrarCol method, of class CRUDColaborador.
     */
    @Test
    public void testRegistrarCol() throws Exception {
        System.out.println("RegistrarCol");
        Colaborador c = null;
        CRUDColaborador instance = new CRUDColaborador();
        instance.RegistrarCol(c);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of mostrarCol method, of class CRUDColaborador.
     */
    @Test
    public void testMostrarCol() throws Exception {
        System.out.println("mostrarCol");
        JTable tabla = null;
        CRUDColaborador instance = new CRUDColaborador();
        instance.mostrarCol(tabla);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of mostrarMed method, of class CRUDColaborador.
     */
    @Test
    public void testMostrarMed() throws Exception {
        System.out.println("mostrarMed");
        JTable tabla = null;
        String esp = "";
        CRUDColaborador instance = new CRUDColaborador();
        instance.mostrarMed(tabla, esp);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of llenarcombo method, of class CRUDColaborador.
     */
    @Test
    public void testLlenarcombo() throws Exception {
        System.out.println("llenarcombo");
        JComboBox cbox = null;
        CRUDColaborador instance = new CRUDColaborador();
        instance.llenarcombo(cbox);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
