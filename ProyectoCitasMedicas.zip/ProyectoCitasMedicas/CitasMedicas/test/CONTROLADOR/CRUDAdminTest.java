/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLADOR;

import MODELO.Administrador;
import MODELO.Especialidad;
import MODELO.Medico;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JTable;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alexa
 */
public class CRUDAdminTest {
    
    public CRUDAdminTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of registrarMed method, of class CRUDAdmin.
     */
    @Test
    public void testRegistrarMed() {
        System.out.println("registrarMed");
        Medico m = null;
        CRUDAdmin instance = new CRUDAdmin();
        instance.registrarMed(m);
        assertTrue( true);
    }

    /**
     * Test of BuscarMed method, of class CRUDAdmin.
     */
    @Test
    public void testBuscarMed() {
        System.out.println("BuscarMed");
        String cedula = "";
        CRUDAdmin instance = new CRUDAdmin();
        Medico expResult = instance.m;
        Medico result = instance.BuscarMed(cedula);
        assertEquals(expResult, result);
      if(result !=expResult){
          assertTrue(true);
    }
    }
    /**
     * Test of Inciarlogin method, of class CRUDAdmin.
     */
    @Test
    public void testInciarlogin() {
        System.out.println("Inciarlogin");
        String user = "";
        String pass = "";
        CRUDAdmin instance = new CRUDAdmin();
        Administrador expResult = null;
        Administrador result = instance.Inciarlogin(user, pass);
        assertEquals(expResult, result);
        assertTrue(true);
    }

    /**
     * Test of llenarcombo method, of class CRUDAdmin.
     */
    @Test
    public void testLlenarcombo() throws Exception {
        System.out.println("llenarcombo");
        JComboBox cbox = null;
        CRUDAdmin instance = new CRUDAdmin();
        instance.llenarcombo(cbox);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of RegistrarEsp method, of class CRUDAdmin.
     */
    @Test
    public void testRegistrarEsp() throws Exception {
        System.out.println("RegistrarEsp");
        Especialidad e = null;
        CRUDAdmin instance = new CRUDAdmin();
        instance.RegistrarEsp(e);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of ActualizarEsp method, of class CRUDAdmin.
     */
    @Test
    public void testActualizarEsp() throws Exception {
        System.out.println("ActualizarEsp");
        String es = "";
        CRUDAdmin instance = new CRUDAdmin();
        instance.ActualizarEsp(es);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of listarEsp method, of class CRUDAdmin.
     */
    @Test
    public void testListarEsp() throws Exception {
        System.out.println("listarEsp");
        JTable tabla = null;
        CRUDAdmin instance = new CRUDAdmin();
        instance.listarEsp(tabla);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of ActualizarTabla method, of class CRUDAdmin.
     */
    @Test
    public void testActualizarTabla() throws Exception {
        System.out.println("ActualizarTabla");
        String esp = "";
        int id = 0;
        CRUDAdmin instance = new CRUDAdmin();
        int expResult = 0;
        int result = instance.ActualizarTabla(esp, id);
        assertEquals(expResult, result);
       if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of llenarhora method, of class CRUDAdmin.
     */
    @Test
    public void testLlenarhora() {
        System.out.println("llenarhora");
        JComboBox cbox = null;
        CRUDAdmin instance = new CRUDAdmin();
        instance.llenarhora(cbox);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of llenarMinutos method, of class CRUDAdmin.
     */
    @Test
    public void testLlenarMinutos() {
        System.out.println("llenarMinutos");
        JComboBox cbox = null;
        CRUDAdmin instance = new CRUDAdmin();
        instance.llenarMinutos(cbox);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of llenarseg method, of class CRUDAdmin.
     */
    @Test
    public void testLlenarseg() {
        System.out.println("llenarseg");
        JComboBox cbox = null;
        CRUDAdmin instance = new CRUDAdmin();
        instance.llenarseg(cbox);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of ListarM method, of class CRUDAdmin.
     */
    @Test
    public void testListarM() throws Exception {
        System.out.println("ListarM");
        CRUDAdmin instance = new CRUDAdmin();
        List<Medico> expResult = null;
        List<Medico> result = instance.ListarM();
        assertEquals(expResult, result);
      if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of ListarE method, of class CRUDAdmin.
     */
    @Test
    public void testListarE() throws Exception {
        System.out.println("ListarE");
        CRUDAdmin instance = new CRUDAdmin();
        List<Especialidad> expResult = null;
        List<Especialidad> result = instance.ListarE();
        assertEquals(expResult, result);
       if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of BuscarEspe method, of class CRUDAdmin.
     */
    @Test
    public void testBuscarEspe() {
        System.out.println("BuscarEspe");
        int codigo = 0;
        CRUDAdmin instance = new CRUDAdmin();
        Especialidad expResult = null;
        Especialidad result = instance.BuscarEspe(codigo);
        assertEquals(expResult, result);
    if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }
    
}
