/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLADOR;

import MODELO.Cita;
import MODELO.Medico;
import MODELO.Paciente;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alexa
 */
public class CRUDCitasTest {
    
    public CRUDCitasTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of crear method, of class CRUDCitas.
     */
    @Test
    public void testCrear() throws Exception {
        System.out.println("crear");
        Cita c = null;
        CRUDCitas instance = new CRUDCitas();
        instance.crear(c);
     
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    

    /**
     * Test of buscarCita method, of class CRUDCitas.
     */
    @Test
    public void testBuscarCita() {
        System.out.println("buscarCita");
        int codigo = 1;
        CRUDCitas instance = new CRUDCitas();
        List<Cita> expResult = null;
        List<Cita> result = instance.buscarCita(codigo);
        assertEquals(expResult, result);
       if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of Buscar method, of class CRUDCitas.
     */
    @Test
    public void testBuscar_int() {
        System.out.println("Buscar");
        int codigo = 0;
        CRUDCitas instance = new CRUDCitas();
        Cita expResult = null;
        Cita result = instance.Buscar(codigo);
        assertEquals(expResult, result);
       if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of ListarM method, of class CRUDCitas.
     */
    @Test
    public void testListarM() throws Exception {
        System.out.println("ListarM");
        CRUDCitas instance = new CRUDCitas();
        List<Medico> expResult = null;
        List<Medico> result = instance.ListarM();
        assertEquals(expResult, result);
        if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of ListarP method, of class CRUDCitas.
     */
    @Test
    public void testListarP() throws Exception {
        System.out.println("ListarP");
        CRUDCitas instance = new CRUDCitas();
        List<Paciente> expResult = null;
        List<Paciente> result = instance.ListarP();
        assertEquals(expResult, result);
        if(result !=expResult){
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    }

    /**
     * Test of Buscar method, of class CRUDCitas.
     */
    @Test
    public void testBuscar_String() {
        System.out.println("Buscar");
        String cedula = "0107593873";
        CRUDCitas instance = new CRUDCitas();
        Paciente expResult = null;
    }
    
}
